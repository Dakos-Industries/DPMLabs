package ev3Nav;
import lejos.hardware.motor.*;

public class WallDetection implements UltrasonicController{
	private final int bandCenter, bandwidth;
	private final int motorLow, motorHigh;
	private int distance;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	private final int FILTER_OUT = 20; private int filterControl;
	
	public WallDetection(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
							  int bandCenter, int bandwidth, int motorLow, int motorHigh) {
		//Default Constructor
		this.bandCenter = bandCenter;
		this.bandwidth = bandwidth;
		this.motorLow = motorLow;
		this.motorHigh = motorHigh;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		leftMotor.setSpeed(motorHigh);				// Start robot moving forward
		rightMotor.setSpeed(motorHigh);
		leftMotor.forward();
		rightMotor.forward();
		filterControl = 0;
	}
	
	@Override
	public void processUSData(int distance) {
		
				if (distance < 15){
					
					rightMotor.stop();
					leftMotor.stop();
					
				}
		
		
	}
	/////////////////////////////////////////////////////////////////////////////

	@Override
	public int readUSDistance() {
		return this.distance;
	}
}
