/*Spiros Mavroidakos 260689391
 * 
 * This Class is used to navigate from the predetermined waypoints
 * as given in the assignment and uses the turnTo() and
 * turnTo() method in order to accomplish this
 * 
 */
package ev3Nav;

import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class NavDriver {
	
	private  final int FORWARD_SPEED = 200; // set a forward speed
	private  final int ROTATE_SPEED = 150; // set a rotate speed
	private boolean navigating = false; // will be used for the isNavigating metho
	
	
	//public  double distance; // will be used to store the distance from the waypoint 
	public  double prevAngle = 0;// will be used to contain the previous angle as a way to reset the robot
	
	//EV3 motors
	public  EV3LargeRegulatedMotor leftMotor; 
	public  EV3LargeRegulatedMotor rightMotor;
	//Wheel radius and width
	public  double leftRadius;
	public  double rightRadius;
	public  double width; 
	
	public  TextLCD t;
	private double prevA = 0; // will hold the previous angle of the robot for use in the turnTo method
							// the prevAngle variable could not be used for this as well because the value
				//of prevA is the previous angle before a correction while the prevAngle is the angle before the 
		//return to original axis.
	Odometer odometer = new Odometer(leftMotor, rightMotor);// initialising odometer
	
	//Constructor for the object
	public NavDriver(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
			double leftRadius, double rightRadius, double width, TextLCD t){
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		this.leftRadius = leftRadius;
		this.rightRadius = rightRadius;
		this.width = width;
		this.t = t;
		
	}
	// the method to make the robot move to the waypoints
	public  void drive() {
		// reset the motors
		for (EV3LargeRegulatedMotor motor : new EV3LargeRegulatedMotor[] { leftMotor, rightMotor }) {
			motor.stop();
			motor.setAcceleration(3000);
		}
		odometer = new Odometer(leftMotor, rightMotor);//odometer object
		OdometryDisplay odometryDisplay = new OdometryDisplay(odometer,t);//initialise the display

		// wait 5 seconds
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// there is nothing to be done here because it is not expected that
			// the odometer will be interrupted by another thread
		}
		//start the threads and the begin travelling to the waypoints
		odometer.start();
		odometryDisplay.start();
		travelTo(60,30);
		
		travelTo(30,30);
		
		travelTo(30,60);
		
		travelTo(60,0);
		
	}
	
	// comvertDistance and convertAngle were given by the sample code
	//from lab2
	private int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}

	private int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius,  width * angle);
	}
	
	
	public void travelTo(double x, double y){
		double DestX = x - odometer.getX(); // gets the "overall" distance in the x-dir
		double DestY = y - odometer.getY();// gets the "overall" distance in he y-dir
		navigating = true;//the method is in use
		
		
		double travelAngle = Math.atan2(  DestX,  DestY); // angle needed to turn
		//prevAngle = travelAngle;
		boolean cont = true; // boolean condition to continue while loop below
		
		while ( cont ){
			// if the distance away from the waypoint is acceptable stop the robot
			if ( Math.abs( x - odometer.getX()) < 0.75 && Math.abs(y - odometer.getY()) < 0.75){
				cont = false; // to stop the while loop;
				leftMotor.stop(); // stop the robot
				rightMotor.stop();
				break;
			}
			DestX = x - odometer.getX(); // update distance
			DestY = y - odometer.getY(); // update distance
			travelAngle = Math.atan2(  DestX,  DestY); // calculates the turn angle
			turnTo(travelAngle);//make the turn
			 navigating = true;//still navigation
		}
		prevAngle = odometer.getTheta(); // gets current angle right before reset
		
		// if the robot is already in reset position do not reset
		if (Math.abs(convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,prevAngle)/2 - 90) > 2){
	
			//this resets the robot to be facing the y-axis
			//this is usefull for travelling to the specified waypoints 
			//it helps to turn the minimal angle
			leftMotor.setSpeed(ROTATE_SPEED);
			rightMotor.setSpeed(ROTATE_SPEED);

			leftMotor.rotate(-convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,prevAngle)/2, true);
			rightMotor.rotate( convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,prevAngle)/2, false);
		}
		prevA = 0; // reset the prevA variable
		navigating = false;// no longer navigation
	}
	
	// used to turn
	public void turnTo(double angle){
		navigating = true; // we are navigating
		// if the angle needs to be corrected than do it 
		// the if variables are in rads
		//compares the prevous angle to the current angle
		if (Math.abs(angle - prevA) > 0.06){
			
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		//makes the correction on the angle based on the current and previous angles
		if (Math.abs(angle - prevA) < 6){
		leftMotor.rotate(convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,angle -  prevA)/2 , true);
		rightMotor.rotate( -convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,angle -  prevA)/2, false);
		}
	
		prevA = angle; // makes the previous angle the current angle
		
		
		}
		//if the angle is acceptable go forward at the FORWARD_SPEED
		leftMotor.setSpeed(FORWARD_SPEED);
		rightMotor.setSpeed(FORWARD_SPEED);
		leftMotor.forward();
		rightMotor.forward();
		
		navigating = false; // we are no longer navigating
	}
	
	// returns if turnTo() or travelTo() are in use
	public boolean isNavigating(){
		return this.navigating;
		
	}
}