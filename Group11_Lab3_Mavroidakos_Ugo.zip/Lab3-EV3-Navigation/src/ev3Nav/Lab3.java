/*
	Spiros Mavroidakos 260689391
	This is the main class that will call the others in order to make
	the robot complete lab3

*/
package ev3Nav;


import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;


public class Lab3 {

	// Initializing the motors to the proper ports
	
	private static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));
	private static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));
	
	//Defining some constants
	public static final double WHEEL_RADIUS = 2.15;
	public static final double TRACK = 15.3;
	
	
	//Us sensor
	private static final int bandCenter = 20;			// Offset from the wall (cm)
	private static final int bandWidth = 10;				// Width of dead band (cm)
	private static final Port usPort = LocalEV3.get().getPort("S1");
	
	public static void main(String args[]){
		
		//sets up the US along with the poller and controller
		SensorModes usSensor = new EV3UltrasonicSensor(usPort);		// usSensor is the instance
		SampleProvider usDistance = usSensor.getMode("Distance");	// usDistance provides samples from this instance
		float[] usData = new float[usDistance.sampleSize()];
		UltrasonicPoller usPoller = null;
		
		int buttonChoice;
		
		// some objects that need to be instantiated
		
		TextLCD t = LocalEV3.get().getTextLCD();
		final NavDriver driver = new NavDriver(leftMotor, rightMotor,
				WHEEL_RADIUS, WHEEL_RADIUS, TRACK,t);
		final AvoidanceDriver Avdriver = new AvoidanceDriver(leftMotor, rightMotor,
				WHEEL_RADIUS, WHEEL_RADIUS, TRACK,t);
		
		do {
			// clear the display
			t.clear();

			// ask the user whether the motors should drive in a square or float
			t.drawString("< Left  | Right >", 0, 0);
			t.drawString("        |        ", 0, 1);
			t.drawString(" Avoid  | Nav  ", 0, 2);
			t.drawString("Obstacle| To   ", 0, 3);
			t.drawString(" Nav    | Waypoints ", 0, 4);

			buttonChoice = Button.waitForAnyPress();
		} while (buttonChoice != Button.ID_LEFT
				&& buttonChoice != Button.ID_RIGHT);

		if (buttonChoice == Button.ID_LEFT) {
			
			// if this was chosen then we are using the wall avoidance navigation
			//the US Thread begins
			usPoller = new UltrasonicPoller(usDistance, usData, Avdriver);
			usPoller.start();
			//run the methods in the AvoidanceDriver class
			(new Thread() {
				public void run() {
					Avdriver.drive();
				}
			}).start();
			
			
		}else {
			// travel to the specified waypoint with no wall avoidance
			(new Thread() {
				public void run() {
					driver.drive();
				}
			}).start();
		}
		//escape command
		while (Button.waitForAnyPress() != Button.ID_ESCAPE);
		System.exit(0);
		
	}
	
	
	
	
}
