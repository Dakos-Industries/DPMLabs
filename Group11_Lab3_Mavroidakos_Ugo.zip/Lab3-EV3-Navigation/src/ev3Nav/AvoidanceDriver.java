/*
 * Spiros Mavroidakos 260689391
 * This method uses the variables as the navDriver class and will
 * Therefore not be as commented as the navDriver class
 * due to redundancy. the turnTo and TravelTo methods function in the same way as 
 * does the isNavigating method. the only difference is that  we are using 
 * the distance gotten by the us to turn either left or right
*/

package ev3Nav;

import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;


public class AvoidanceDriver implements UltrasonicController{
	
	private  final int FORWARD_SPEED = 200;
	private  final int ROTATE_SPEED = 150;
	
	public boolean navigating = false;
	public  int distance;
	public  double prevAngle = 0;
	public  EV3LargeRegulatedMotor leftMotor; 
	public  EV3LargeRegulatedMotor rightMotor;
	public  double leftRadius;
	public  double rightRadius;
	public  double width; 
	public  TextLCD t;
	private double prevA = 0;
	Odometer odometer = new Odometer(leftMotor, rightMotor);
	
	
	
	//Costructor
		public AvoidanceDriver(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
			double leftRadius, double rightRadius, double width, TextLCD t){
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		this.leftRadius = leftRadius;
		this.rightRadius = rightRadius;
		this.width = width;
		this.t = t;
		
	}
	public  void drive() {
		// reset the motors
		for (EV3LargeRegulatedMotor motor : new EV3LargeRegulatedMotor[] { leftMotor, rightMotor }) {
			motor.stop();
			motor.setAcceleration(3000);
		}
		
		
		odometer = new Odometer(leftMotor, rightMotor);
		OdometryDisplay odometryDisplay = new OdometryDisplay(odometer,t);
		
		

		// wait 5 seconds
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// there is nothing to be done here because it is not expected that
			// the odometer will be interrupted by another thread
		}

		
		odometer.start();
		odometryDisplay.start();
		travelTo(0,60);
		
		travelTo(60,0);
		
	}
	private int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}

	private int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius,  width * angle);
	}

	
	public void travelTo(double x, double y){
		double DestX = x - odometer.getX();
		double DestY = y - odometer.getY();
		navigating = true;
		
		
		double travelAngle = Math.atan2(  DestX,  DestY);
		//prevAngle = travelAngle;
		boolean cont = true;
		while ( cont ){
			if ( Math.abs( x - odometer.getX()) < 1.5 && Math.abs(y - odometer.getY()) < 1.5){
				cont = false;
				leftMotor.stop();
				rightMotor.stop();
				break;
			}
			 // While the distance from the wall is not acceptable turn away from it and 
			// continue until it is acceptable to turn back and go to the waypoint
			 while (distance <= 22){
				
				 leftMotor.setSpeed(ROTATE_SPEED);
				 rightMotor.setSpeed(ROTATE_SPEED);
				 // turn away from the wall
				 leftMotor.rotate(convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,Math.PI/2)/2, true);
				 rightMotor.rotate( -convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,Math.PI/2)/2, false);
				 
				 leftMotor.setSpeed(300);
				 rightMotor.setSpeed(300);
				 leftMotor.forward();
				 rightMotor.forward();
				 
				 try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					
				}
				 //undo most of the previous turn to continue to the waypoint
				 leftMotor.rotate( -convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,Math.PI/3)/2, true);
				 rightMotor.rotate( convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,Math.PI/3)/2, false);
				 
				
			}
			
			DestX = x - odometer.getX();
			DestY = y - odometer.getY();
			travelAngle = Math.atan2(  DestX,  DestY); // calculates the turn angle
			turnTo(travelAngle);
			navigating = true;
		}
		 //prevAngle = odometer.getTheta();
		
		/*if (Math.abs(convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,prevAngle)/2 - 90 ) > 2){
	
			leftMotor.setSpeed(ROTATE_SPEED);
			rightMotor.setSpeed(ROTATE_SPEED);

			leftMotor.rotate(-convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,prevAngle)/2, true);
			rightMotor.rotate( convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,prevAngle)/2, false);
		}
		prevA = 0;*/
		navigating = false; // no longer calling the travelTo method
	}
	
	public void turnTo(double angle){
		
		navigating = true;
		if (Math.abs(angle - prevA) > 0.08){
			
			// Once the robot avoids a wall and reaches the waypoint,
			// this if statements makes sure that an optimal angle is achieved 
			// when the robot is turning to get to the next waypoint
			if (Math.abs(angle - prevA) > Math.PI){
				
				angle = angle + Math.PI/3;
			} 
		// regular turnTo method as seen in the preious class
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		if (Math.abs(angle - prevA) < 6){
			leftMotor.rotate(convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,angle -  prevA)/2 , true);
			rightMotor.rotate( -convertAngle(Lab3.WHEEL_RADIUS, Lab3.TRACK,angle -  prevA)/2, false);
		}
		
		prevA = angle;
		
		
		}
		//go forward
		leftMotor.setSpeed(FORWARD_SPEED);
		rightMotor.setSpeed(FORWARD_SPEED);
		leftMotor.forward();
		rightMotor.forward();
		navigating = false;// no longer calling the turnTo method
	}
	
	//process and read the US data
	@Override
	public void processUSData(int distance) {
		this.distance = distance;
		
	}
	@Override
	public int readUSDistance() {
		// TODO Auto-generated method stub
		return this.distance;
	}
	// returns if turnTo() or travelTo() are in use
		public boolean isNavigating(){
			return this.navigating;
			
		}
}