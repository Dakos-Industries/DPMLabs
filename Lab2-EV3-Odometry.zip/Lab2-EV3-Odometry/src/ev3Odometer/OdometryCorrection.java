/* 
 * OdometryCorrection.java
 */
package ev3Odometer;

import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

public class OdometryCorrection extends Thread {
	private static final long CORRECTION_PERIOD = 10;
	
	//public static Port sensorPort = LocalEV3.get().getPort("S1");   
	public static Port portColor = LocalEV3.get().getPort("S1");
	public static SensorModes myColor = new EV3ColorSensor(portColor);
	public static SampleProvider myColorSample = myColor.getMode("Red");
	public static float[] sampleColor = new float[myColor.sampleSize()];
	public static int numSamples = 0;
	private Odometer odometer;
	
	
	// constructor
	public OdometryCorrection(Odometer odometer) {
		this.odometer = odometer;
	}

	// run method (required for Thread)
	public void run() {
		long correctionStart, correctionEnd;
		//int count = 0;
		while (true) {
			correctionStart = System.currentTimeMillis();
	
			// put your correction code here			
			myColorSample.fetchSample(sampleColor,0);
			numSamples++;

			// this ensure the odometry correction occurs only once every period
			correctionEnd = System.currentTimeMillis();
			if (correctionEnd - correctionStart < CORRECTION_PERIOD) {
				try {
					Thread.sleep(CORRECTION_PERIOD
							- (correctionEnd - correctionStart));
				} catch (InterruptedException e) {
					// there is nothing to be done here because it is not
					// expected that the odometry correction will be
					// interrupted by another thread
				}
			}
		}
	}
}